package com.televoip.practica_guiada_db4o;

/**
 *
 * @author telev
 */
public class Main {
    
    public static void main(String[] args) {
        App.runApp(args);
    }
    
}
